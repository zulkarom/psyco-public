<?php
return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=localhost;dbname=psycho_yii',
            'username' => 'root',
            'password' => '',
            'charset' => 'utf8',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'viewPath' => '@common/mail',
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
            'useFileTransport' => true,
        ],
		
	 	'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => false,
            'rules' => [
			

			
            //'showScriptName' => false,
            //'rules' => [
			//'product/search-jakim/<cari>/<ty>/<page>/<hdnCounter>' => //'product/search-jakim', 
			//'<controller>/<action>' => '<controller>/<action>',
			//'product/add-product-jakim/<product_name:\w+>/<company:\w+>/<company_id:\w+>/<expired_date:\w+>/<ty:\w+>' => 'product/add-product-jakim',
			
			//'<controller/<id:\d+>'
			//'posts/<year:\d{4}>/<category>' => 'post/index',
			//'posts' => 'post/index',
			//'post/<id:\d+>' => 'post/view',
			
            ],
        ], 
    ],
];
